/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.raven.form;

import java.awt.Color;
import java.awt.geom.RoundRectangle2D;
import control.EmployeesControl;
import exception.*;
import java.awt.Cursor;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;
import model.Employees;
import model.Administrators;
import table.TableEmployees;
//import view.LoginView;
//import view.LoginView;

/**
 *
 * @author RAVEN
 */
public class ManageEmployeeView1 extends javax.swing.JPanel {
    private EmployeesControl employeesControl;
    private Administrators admin;
    String action = null;
    List<Employees> listEmployees;
    int selectedId = 0;
    
//    public void initJ(){
//        setLocationRelativeTo(null);
//        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 20, 20));
//    }
        
//    public void init(){
//        titleBar.initPane(this);
//    }
    
    public ManageEmployeeView1(Administrators admin) {
        initComponents();
        this.admin=admin;
        employeesControl = new EmployeesControl();
        setComponent(false);
        setEditDeleteBtn(false);
        showEmployees();
//        init();
    }
    
    public void setComponent(boolean value){
        idInput.setEnabled(value);
        firstInput.setEnabled(value);
        lastInput.setEnabled(value);
        idLabel.setEnabled(value);
        firstLabel.setEnabled(value);
        lastLabel.setEnabled(value);
        
        passwordInput.setEnabled(value);
        userInput.setEnabled(value);
        passLabel.setEnabled(value);
        userLabel.setEnabled(value);
        
        startWorkDate.setEnabled(value);
        endWorkDate.setEnabled(value);
        startLabel.setEnabled(value);
        endLabel.setEnabled(value);
        
        tellerRadio.setEnabled(value);
        customerRadio.setEnabled(value);
        roleLabel.setEnabled(value);
        
        stationInput.setEnabled(value);
        officeInput.setEnabled(value);
        stationLabel.setEnabled(value);
        officeLabel.setEnabled(value);
        
        saveBtn.setEnabled(value);
        cancelBtn.setEnabled(value);
    }
    
    public void setEditDeleteBtn(boolean value){
        editBtn.setEnabled(value);
        deleteBtn.setEnabled(value);
    }
    
    public void showEmployees(){
        employeeTable.setModel(employeesControl.showEmployees(""));
    }
    
    public void clearText(){
       idInput.setText("");
       firstInput.setText("");
       lastInput.setText("");
       passwordInput.setText("");
       userInput.setText("");
       startWorkDate.setCalendar(null);
       endWorkDate.setCalendar(null);
       stationInput.setText("");
       officeInput.setText("");
       tellerRadio.setSelected(false);
       customerRadio.setSelected(false);
    }
    
    public void blankInputException() throws BlankInputException{
        if(tellerRadio.isSelected()){
            if(idInput.getText().isEmpty() || firstInput.getText().isEmpty() || lastInput.getText().isEmpty()
                || userInput.getText().isEmpty() || String.valueOf(passwordInput.getPassword()).isEmpty()
                || stationInput.getText().isEmpty()){
                throw new BlankInputException();
            }
        }else{
            if(idInput.getText().isEmpty() || firstInput.getText().isEmpty() || lastInput.getText().isEmpty()
                || userInput.getText().isEmpty() || String.valueOf(passwordInput.getPassword()).isEmpty()
                || officeInput.getText().isEmpty()){
                throw new BlankInputException();
            }
        }
    }
    
    public String convDateSql(Date input){
        String dateSql = null;
        Date fromView = input;    
        
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");   
        Date date = new Date(fromView.getTime());
                try {
                    dateSql = format.format(date);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
        
        return dateSql;
    }
    
    public void blankRadioInputException() throws BlankInputException{
        if(tellerRadio.isSelected() || customerRadio.isSelected()){
            throw new BlankInputException();
        }
    }
    
    private void invalidCalendarException() throws InvalidCalendarException{
        if(startWorkDate.getCalendar()==null || endWorkDate.getCalendar()==null){
            throw new InvalidCalendarException();
        }else if(startWorkDate.getCalendar().compareTo(endWorkDate.getCalendar())>0){
            throw new InvalidCalendarException();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        roleBtnGroup = new javax.swing.ButtonGroup();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        addBtn = new javax.swing.JButton();
        editBtn = new javax.swing.JButton();
        deleteBtn = new javax.swing.JButton();
        saveBtn = new javax.swing.JButton();
        cancelBtn = new javax.swing.JButton();
        searchInput = new javax.swing.JTextField();
        searchBtn = new javax.swing.JButton();
        panelBorder12 = new com.raven.swing.PanelBorder1();
        idLabel = new javax.swing.JLabel();
        idInput = new javax.swing.JTextField();
        firstLabel = new javax.swing.JLabel();
        firstInput = new javax.swing.JTextField();
        lastLabel = new javax.swing.JLabel();
        lastInput = new javax.swing.JTextField();
        panelBorder13 = new com.raven.swing.PanelBorder1();
        userLabel = new javax.swing.JLabel();
        userInput = new javax.swing.JTextField();
        passwordInput = new javax.swing.JPasswordField();
        passLabel = new javax.swing.JLabel();
        panelBorder14 = new com.raven.swing.PanelBorder1();
        roleLabel = new javax.swing.JLabel();
        tellerRadio = new javax.swing.JRadioButton();
        customerRadio = new javax.swing.JRadioButton();
        stationLabel = new javax.swing.JLabel();
        stationInput = new javax.swing.JTextField();
        officeLabel = new javax.swing.JLabel();
        officeInput = new javax.swing.JTextField();
        panelBorder15 = new com.raven.swing.PanelBorder1();
        startLabel = new javax.swing.JLabel();
        startWorkDate = new com.toedter.calendar.JDateChooser();
        endLabel = new javax.swing.JLabel();
        endWorkDate = new com.toedter.calendar.JDateChooser();
        panelBorder16 = new com.raven.swing.PanelBorder1();
        jScrollPane1 = new javax.swing.JScrollPane();
        employeeTable = new javax.swing.JTable();

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jPanel3.setBackground(new java.awt.Color(226, 226, 226));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Krungthep", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(28, 94, 32));
        jLabel2.setText("Administrators");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel2)
                .addContainerGap(721, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel2)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        addBtn.setBackground(new java.awt.Color(25, 135, 84));
        addBtn.setFont(new java.awt.Font("Century Gothic", 1, 17)); // NOI18N
        addBtn.setForeground(new java.awt.Color(255, 255, 255));
        addBtn.setText("Add");
        addBtn.setBorder(null);
        addBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        addBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBtnActionPerformed(evt);
            }
        });

        editBtn.setBackground(new java.awt.Color(241, 196, 15));
        editBtn.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        editBtn.setForeground(new java.awt.Color(255, 255, 255));
        editBtn.setText("Edit");
        editBtn.setBorder(null);
        editBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        editBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editBtnActionPerformed(evt);
            }
        });

        deleteBtn.setBackground(new java.awt.Color(220, 53, 69));
        deleteBtn.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        deleteBtn.setForeground(new java.awt.Color(255, 255, 255));
        deleteBtn.setText("Delete");
        deleteBtn.setBorder(null);
        deleteBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBtnActionPerformed(evt);
            }
        });

        saveBtn.setBackground(new java.awt.Color(13, 110, 253));
        saveBtn.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        saveBtn.setForeground(new java.awt.Color(255, 255, 255));
        saveBtn.setText("Save");
        saveBtn.setBorder(null);
        saveBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        saveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveBtnActionPerformed(evt);
            }
        });

        cancelBtn.setBackground(new java.awt.Color(220, 53, 69));
        cancelBtn.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        cancelBtn.setForeground(new java.awt.Color(255, 255, 255));
        cancelBtn.setText("Batal");
        cancelBtn.setBorder(null);
        cancelBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cancelBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelBtnActionPerformed(evt);
            }
        });

        searchInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchInputActionPerformed(evt);
            }
        });

        searchBtn.setBackground(new java.awt.Color(13, 110, 253));
        searchBtn.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        searchBtn.setForeground(new java.awt.Color(255, 255, 255));
        searchBtn.setText("Search");
        searchBtn.setBorder(null);
        searchBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        searchBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBtnActionPerformed(evt);
            }
        });

        panelBorder12.setPreferredSize(new java.awt.Dimension(230, 202));
        panelBorder12.setRoundBottomLeft(20);
        panelBorder12.setRoundBottomRight(20);
        panelBorder12.setRoundTopLeft(20);
        panelBorder12.setRoundTopRight(20);

        idLabel.setBackground(new java.awt.Color(0, 0, 0));
        idLabel.setFont(new java.awt.Font("Poppins", 1, 14)); // NOI18N
        idLabel.setText("ID Employee");

        idInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idInputActionPerformed(evt);
            }
        });

        firstLabel.setBackground(new java.awt.Color(0, 0, 0));
        firstLabel.setFont(new java.awt.Font("Poppins", 1, 14)); // NOI18N
        firstLabel.setText("First Name");

        firstInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                firstInputActionPerformed(evt);
            }
        });

        lastLabel.setBackground(new java.awt.Color(0, 0, 0));
        lastLabel.setFont(new java.awt.Font("Poppins", 1, 14)); // NOI18N
        lastLabel.setText("Last Name");

        lastInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lastInputActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelBorder12Layout = new javax.swing.GroupLayout(panelBorder12);
        panelBorder12.setLayout(panelBorder12Layout);
        panelBorder12Layout.setHorizontalGroup(
            panelBorder12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder12Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(panelBorder12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lastLabel)
                    .addGroup(panelBorder12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(lastInput, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(idLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(firstLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(firstInput, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(idInput, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelBorder12Layout.setVerticalGroup(
            panelBorder12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder12Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(idLabel)
                .addGap(5, 5, 5)
                .addComponent(idInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(firstLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(firstInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lastLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lastInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panelBorder13.setRoundBottomLeft(20);
        panelBorder13.setRoundBottomRight(20);
        panelBorder13.setRoundTopLeft(20);
        panelBorder13.setRoundTopRight(20);

        userLabel.setBackground(new java.awt.Color(0, 0, 0));
        userLabel.setFont(new java.awt.Font("Poppins", 1, 14)); // NOI18N
        userLabel.setText("Username");

        userInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userInputActionPerformed(evt);
            }
        });

        passLabel.setBackground(new java.awt.Color(0, 0, 0));
        passLabel.setFont(new java.awt.Font("Poppins", 1, 14)); // NOI18N
        passLabel.setText("Password");

        javax.swing.GroupLayout panelBorder13Layout = new javax.swing.GroupLayout(panelBorder13);
        panelBorder13.setLayout(panelBorder13Layout);
        panelBorder13Layout.setHorizontalGroup(
            panelBorder13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder13Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(panelBorder13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(userLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(passLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(userInput, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addComponent(passwordInput))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        panelBorder13Layout.setVerticalGroup(
            panelBorder13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder13Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(userLabel)
                .addGap(5, 5, 5)
                .addComponent(userInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(passLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(passwordInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panelBorder14.setRoundBottomLeft(20);
        panelBorder14.setRoundBottomRight(20);
        panelBorder14.setRoundTopLeft(20);
        panelBorder14.setRoundTopRight(20);

        roleLabel.setBackground(new java.awt.Color(0, 0, 0));
        roleLabel.setFont(new java.awt.Font("Poppins Medium", 1, 14)); // NOI18N
        roleLabel.setText("Role");

        roleBtnGroup.add(tellerRadio);
        tellerRadio.setFont(new java.awt.Font("Poppins Medium", 0, 14)); // NOI18N
        tellerRadio.setText("Teller");
        tellerRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tellerRadioActionPerformed(evt);
            }
        });

        roleBtnGroup.add(customerRadio);
        customerRadio.setFont(new java.awt.Font("Poppins Medium", 0, 14)); // NOI18N
        customerRadio.setText("Customer Service");
        customerRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                customerRadioActionPerformed(evt);
            }
        });

        stationLabel.setBackground(new java.awt.Color(0, 0, 0));
        stationLabel.setFont(new java.awt.Font("Poppins", 1, 14)); // NOI18N
        stationLabel.setText("Station Number");

        stationInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stationInputActionPerformed(evt);
            }
        });

        officeLabel.setBackground(new java.awt.Color(0, 0, 0));
        officeLabel.setFont(new java.awt.Font("Poppins", 1, 14)); // NOI18N
        officeLabel.setText("Office Number");

        officeInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                officeInputActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelBorder14Layout = new javax.swing.GroupLayout(panelBorder14);
        panelBorder14.setLayout(panelBorder14Layout);
        panelBorder14Layout.setHorizontalGroup(
            panelBorder14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder14Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(panelBorder14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(roleLabel)
                    .addComponent(tellerRadio, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(customerRadio)
                    .addGroup(panelBorder14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(stationInput, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(officeInput, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(officeLabel, javax.swing.GroupLayout.Alignment.LEADING))
                    .addComponent(stationLabel))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        panelBorder14Layout.setVerticalGroup(
            panelBorder14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(roleLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tellerRadio)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(customerRadio)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(stationLabel)
                .addGap(5, 5, 5)
                .addComponent(stationInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(officeLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(officeInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(10, Short.MAX_VALUE))
        );

        panelBorder15.setRoundBottomLeft(20);
        panelBorder15.setRoundBottomRight(20);
        panelBorder15.setRoundTopLeft(20);
        panelBorder15.setRoundTopRight(20);

        startLabel.setBackground(new java.awt.Color(0, 0, 0));
        startLabel.setFont(new java.awt.Font("Poppins", 1, 14)); // NOI18N
        startLabel.setText("Start Work Date");

        endLabel.setBackground(new java.awt.Color(0, 0, 0));
        endLabel.setFont(new java.awt.Font("Poppins", 1, 14)); // NOI18N
        endLabel.setText("End Work Date");

        javax.swing.GroupLayout panelBorder15Layout = new javax.swing.GroupLayout(panelBorder15);
        panelBorder15.setLayout(panelBorder15Layout);
        panelBorder15Layout.setHorizontalGroup(
            panelBorder15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder15Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(panelBorder15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(endLabel)
                    .addComponent(startLabel)
                    .addComponent(startWorkDate, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(endWorkDate, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelBorder15Layout.setVerticalGroup(
            panelBorder15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder15Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(startLabel)
                .addGap(5, 5, 5)
                .addComponent(startWorkDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(endLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(endWorkDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        panelBorder16.setRoundBottomLeft(20);
        panelBorder16.setRoundBottomRight(20);
        panelBorder16.setRoundTopLeft(20);
        panelBorder16.setRoundTopRight(20);

        employeeTable.setBackground(new java.awt.Color(255, 254, 243));
        employeeTable.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        employeeTable.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        employeeTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        employeeTable.setGridColor(new java.awt.Color(218, 218, 218));
        employeeTable.setRowHeight(35);
        employeeTable.setSelectionBackground(new java.awt.Color(93, 143, 44));
        employeeTable.setShowGrid(true);
        employeeTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                employeeTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(employeeTable);

        javax.swing.GroupLayout panelBorder16Layout = new javax.swing.GroupLayout(panelBorder16);
        panelBorder16.setLayout(panelBorder16Layout);
        panelBorder16Layout.setHorizontalGroup(
            panelBorder16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder16Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 956, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );
        panelBorder16Layout.setVerticalGroup(
            panelBorder16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder16Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(10, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(panelBorder16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(addBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(editBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(panelBorder12, javax.swing.GroupLayout.DEFAULT_SIZE, 226, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(deleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(searchInput, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(searchBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(panelBorder13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(panelBorder14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(cancelBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(saveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(panelBorder15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                .addGap(30, 30, 30))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(addBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(deleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(editBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(searchInput)
                    .addComponent(searchBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(panelBorder15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(saveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cancelBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(panelBorder13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelBorder14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelBorder12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(panelBorder16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(3, 3, 3))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void addBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addBtnActionPerformed
        setEditDeleteBtn(false);
        setComponent(true);
        stationInput.setEnabled(false);
        officeInput.setEnabled(false);
        stationLabel.setEnabled(false);
        officeLabel.setEnabled(false);
        clearText();
        roleBtnGroup.clearSelection();
        idInput.setEditable(false);
        idInput.setText(String.valueOf(employeesControl.autoGenerateID()));
        action = "Add";
    }//GEN-LAST:event_addBtnActionPerformed

    private void editBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editBtnActionPerformed
        addBtn.setEnabled(false);
        deleteBtn.setEnabled(false);
        setComponent(true);
        stationInput.setEnabled(false);
        officeInput.setEnabled(false);
        stationLabel.setEnabled(false);
        officeLabel.setEnabled(false);
        idInput.setEnabled(false);
        action = "Change";
    }//GEN-LAST:event_editBtnActionPerformed

    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBtnActionPerformed
        int getAnswer = JOptionPane.showConfirmDialog(this, "Yakin menghapus pegawai?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
        if(getAnswer == 0){
            try{
                employeesControl.deleteEmployees(Integer.parseInt(idInput.getText()));
                clearText();
                setComponent(false);
                setEditDeleteBtn(false);
                addBtn.setEnabled(true);
                showEmployees();
                JOptionPane.showMessageDialog(this, "Berhasil menghapus pegawai");
            } catch(Exception e){
                System.out.println("Error deleting data...");
                System.out.println(e);
            }
        }
    }//GEN-LAST:event_deleteBtnActionPerformed

    private void saveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveBtnActionPerformed
        try{
            blankInputException();
            invalidCalendarException();
            if(action.equals("Add")){
                int getAnswer = JOptionPane.showConfirmDialog(this, "Yakin menambahkan pegawai?","Konfirmasi", JOptionPane.YES_NO_OPTION);
                if(getAnswer == JOptionPane.YES_OPTION){
                    if(tellerRadio.isSelected()){
                        Employees e = new Employees (Integer.parseInt(idInput.getText()), firstInput.getText(), lastInput.getText(), userInput.getText(),String.valueOf(passwordInput.getPassword()) ,
                            convDateSql(startWorkDate.getDate()), convDateSql(endWorkDate.getDate()), 1, officeInput.getText(), stationInput.getText());
                        employeesControl.insertEmployees(e);
                        JOptionPane.showMessageDialog(this, "Berhasil menambahkan pegawai");
                    }else{
                        Employees e = new Employees (Integer.parseInt(idInput.getText()), firstInput.getText(), lastInput.getText(), userInput.getText(), String.valueOf(passwordInput.getPassword()),
                            convDateSql(startWorkDate.getDate()), convDateSql(endWorkDate.getDate()), 2, officeInput.getText(), stationInput.getText());
                        employeesControl.insertEmployees(e);
                        JOptionPane.showMessageDialog(this, "Berhasil menambahkan pegawai");
                    }
                }else {
                    JOptionPane.showMessageDialog(this, "Batal menambahkan pegawai");
                }
            }else{
                int getAnswer = JOptionPane.showConfirmDialog(this, "Yakin memperbarui pegawai?","Konfirmasi", JOptionPane.YES_NO_OPTION);
                if(getAnswer == JOptionPane.YES_OPTION){
                    if(tellerRadio.isSelected()){
                        Employees e = new Employees (Integer.parseInt(idInput.getText()), firstInput.getText(), lastInput.getText(), userInput.getText(), String.valueOf(passwordInput.getPassword()),
                            convDateSql(startWorkDate.getDate()), convDateSql(endWorkDate.getDate()), 1, officeInput.getText(), stationInput.getText());
                        employeesControl.updateEmployees(e);
                        JOptionPane.showMessageDialog(this, "Berhasil memperbarui pegawai");
                    }else{
                        Employees e = new Employees (Integer.parseInt(idInput.getText()), firstInput.getText(), lastInput.getText(), userInput.getText(), String.valueOf(passwordInput.getPassword()),
                            convDateSql(startWorkDate.getDate()), convDateSql(endWorkDate.getDate()), 2, officeInput.getText(), stationInput.getText());
                        employeesControl.updateEmployees(e);
                        JOptionPane.showMessageDialog(this, "Berhasil memperbarui pegawai");
                    }
                }else {
                    JOptionPane.showMessageDialog(this, "Batal memperbarui pegawai");
                }
            }
            clearText();
            setComponent(false);
            setEditDeleteBtn(false);
            roleBtnGroup.clearSelection();
            showEmployees();
        } catch(BlankInputException e){
            JOptionPane.showConfirmDialog(null, e.message(), "Warning", JOptionPane.DEFAULT_OPTION);
            System.out.println("Error: " + e.toString());
        }catch(InvalidCalendarException e1){
            JOptionPane.showConfirmDialog(null, e1.message(), "Warning", JOptionPane.DEFAULT_OPTION);
            System.out.println("Error: " + e1.toString());
        }
    }//GEN-LAST:event_saveBtnActionPerformed

    private void cancelBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelBtnActionPerformed
        setComponent(false);
        setEditDeleteBtn(false);
        addBtn.setEnabled(true);
        showEmployees();
        clearText();
        roleBtnGroup.clearSelection();
    }//GEN-LAST:event_cancelBtnActionPerformed

    private void searchInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchInputActionPerformed

    private void searchBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBtnActionPerformed
        setComponent(false);
        setEditDeleteBtn(false);
        try{
            TableEmployees empTab = employeesControl.showTableEmp(searchInput.getText());
            if(empTab.getRowCount()==0){
                clearText();
                searchInput.setText("");
                JOptionPane.showMessageDialog(this, "Pegawai tidak ditemukan!");
            }else{
                employeeTable.setModel(empTab);
            }
            clearText();
            searchInput.setText("");
        }catch (Exception e) {
            System.out.println("Error : "+e.getMessage());
        }
    }//GEN-LAST:event_searchBtnActionPerformed

    private void idInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idInputActionPerformed

    private void firstInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_firstInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_firstInputActionPerformed

    private void lastInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lastInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lastInputActionPerformed

    private void userInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_userInputActionPerformed

    private void tellerRadioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tellerRadioActionPerformed
        officeInput.setEnabled(false);
        officeInput.setText("");
        stationInput.setEnabled(true);
        stationLabel.setEnabled(true);
    }//GEN-LAST:event_tellerRadioActionPerformed

    private void customerRadioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_customerRadioActionPerformed
        officeLabel.setEnabled(true);
        officeInput.setEnabled(true);
        stationInput.setEnabled(false);
        stationInput.setText("");
    }//GEN-LAST:event_customerRadioActionPerformed

    private void stationInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stationInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_stationInputActionPerformed

    private void officeInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_officeInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_officeInputActionPerformed

    private void employeeTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_employeeTableMouseClicked
        setComponent(false);
        setEditDeleteBtn(true);
        cancelBtn.setEnabled(true);
        int clickedRow = employeeTable.getSelectedRow();
        TableModel tableModel = employeeTable.getModel();

        idInput.setText(tableModel.getValueAt(clickedRow, 0).toString());
        firstInput.setText(tableModel.getValueAt(clickedRow, 3).toString());
        lastInput.setText(tableModel.getValueAt(clickedRow, 4).toString());
        passwordInput.setText(tableModel.getValueAt(clickedRow, 2).toString());
        userInput.setText(tableModel.getValueAt(clickedRow, 1).toString());
        Calendar c = Calendar.getInstance();
        c.set(Integer.parseInt(tableModel.getValueAt(clickedRow,5).toString().substring(6, 10)),
            Integer.parseInt(tableModel.getValueAt(clickedRow,5).toString().substring(3, 5))-1,
            Integer.parseInt(tableModel.getValueAt(clickedRow,5).toString().substring(0, 2)));
        startWorkDate.setCalendar(c);
        c.set(Integer.parseInt(tableModel.getValueAt(clickedRow,6).toString().substring(6, 10)),
            Integer.parseInt(tableModel.getValueAt(clickedRow,6).toString().substring(3, 5))-1,
            Integer.parseInt(tableModel.getValueAt(clickedRow,6).toString().substring(0, 2)));
        endWorkDate.setCalendar(c);
        if(tableModel.getValueAt(clickedRow, 7).toString().equals("Teller")){
            tellerRadio.setSelected(true);
        }else if(tableModel.getValueAt(clickedRow, 7).toString().equals("Customer Services")){
            customerRadio.setSelected(true);
        }

        if(tellerRadio.isSelected()){
            stationInput.setText(tableModel.getValueAt(clickedRow, 8).toString());
            officeInput.setText("");
        }else{
            officeInput.setText(tableModel.getValueAt(clickedRow, 9).toString());
            stationInput.setText("");
        }
    }//GEN-LAST:event_employeeTableMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addBtn;
    private javax.swing.JButton cancelBtn;
    private javax.swing.JRadioButton customerRadio;
    private javax.swing.JButton deleteBtn;
    private javax.swing.JButton editBtn;
    private javax.swing.JTable employeeTable;
    private javax.swing.JLabel endLabel;
    private com.toedter.calendar.JDateChooser endWorkDate;
    private javax.swing.JTextField firstInput;
    private javax.swing.JLabel firstLabel;
    private javax.swing.JTextField idInput;
    private javax.swing.JLabel idLabel;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField lastInput;
    private javax.swing.JLabel lastLabel;
    private javax.swing.JTextField officeInput;
    private javax.swing.JLabel officeLabel;
    private com.raven.swing.PanelBorder1 panelBorder12;
    private com.raven.swing.PanelBorder1 panelBorder13;
    private com.raven.swing.PanelBorder1 panelBorder14;
    private com.raven.swing.PanelBorder1 panelBorder15;
    private com.raven.swing.PanelBorder1 panelBorder16;
    private javax.swing.JLabel passLabel;
    private javax.swing.JPasswordField passwordInput;
    private javax.swing.ButtonGroup roleBtnGroup;
    private javax.swing.JLabel roleLabel;
    private javax.swing.JButton saveBtn;
    private javax.swing.JButton searchBtn;
    private javax.swing.JTextField searchInput;
    private javax.swing.JLabel startLabel;
    private com.toedter.calendar.JDateChooser startWorkDate;
    private javax.swing.JTextField stationInput;
    private javax.swing.JLabel stationLabel;
    private javax.swing.JRadioButton tellerRadio;
    private javax.swing.JTextField userInput;
    private javax.swing.JLabel userLabel;
    // End of variables declaration//GEN-END:variables
}
