package exception;

public class InvalidCalendarException extends Exception{
    public String message(){
            return "Inputan Tanggal Invalid !";
        }  
}
