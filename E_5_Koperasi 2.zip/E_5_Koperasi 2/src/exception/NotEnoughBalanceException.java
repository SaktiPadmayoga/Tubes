package exception;

public class NotEnoughBalanceException extends Exception{
    public String message(){
        return "Jumlah uang pengirim tidak cukup";
    }  
}
