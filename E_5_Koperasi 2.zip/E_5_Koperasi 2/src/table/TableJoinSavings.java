/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package table;

import javax.swing.table.AbstractTableModel;
import model.Savings;
import java.util.List;
import model.Transactions;
import model.TransactionsJoins;

public class TableJoinSavings extends AbstractTableModel{
    private List<TransactionsJoins> savings;

    public TableJoinSavings(List<TransactionsJoins> savings) {
        this.savings = savings;
    }
    
    @Override
    public int getRowCount(){
        return savings.size() ;
    }

    @Override
    public int getColumnCount(){
        return 6;
    }

    @Override
    public Object getValueAt(int row, int col){
        switch(col){
            case 0: 
                return savings.get(row).getTn().getTransaction_id();
            case 1: 
                return savings.get(row).getSv().getSaving_id();
            case 2: 
                return savings.get(row).getSv().getSaving_type();
            case 3: 
                return savings.get(row).getSv().getSaving_date();
            case 4: 
                return savings.get(row).getSv().getTo_account_id();
            case 5: 
                return savings.get(row).getSv().getAmount();
            case 6:
                return savings.get(row).getTn().getTransaction_date();
            default: 
                return null;
        }
    }

    @Override
    public String getColumnName(int col){
        switch (col) {
            case 0:
                return "Transcation ID";
            case 1: 
                return "Transfer ID";
            case 2: 
                return "From Account ID";
            case 3: 
                return "To Account ID";
            case 4:
                return "Amount";
            case 5:
                return "Date";
            default: 
                return null;
        }
    }
}
